# Backend Take-home Problem

## 🚀 How to Run
1. Install dependencies:
```bash
poetry install
